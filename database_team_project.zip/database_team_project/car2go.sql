﻿USE master
GO

DROP DATABASE IF EXISTS CAR2GO
GO

-- creating a database
CREATE DATABASE CAR2GO
GO

-- Change connection to employee_practice database
USE CAR2GO
GO


-- creating tables 
/*CREATE TABLE company ( 

    company_id VARCHAR PRIMARY KEY, 

    company_name VARCHAR, 

    description VARCHAR  

); 
*/
     

CREATE TABLE location ( 

    location_id VARCHAR (30), 

    company_name VARCHAR(30) NOT NULL ,
    street VARCHAR(30)not null, 

    city VARCHAR(30) not null, 

    province_branch VARCHAR(30) not null, 

    postal_code_branch VARCHAR(20) not null , 

    company_id VARCHAR(30) not null,
    constraint pk_location primary key(location_id),
 ); 

 

CREATE TABLE car_class ( 

    class_name VARCHAR(30) , 

    cost_per_day MONEY not null,
    constraint fk_car_class PRIMARY KEY(class_name)

 ); 

 

CREATE TABLE car ( 

    plate char(9), 

    vin char(7)  not null unique , 

    year DATE not null, 

    make char(10) not null, 

    model char(10) not null, 

    color varchar(15) not null , 

    class_name VARCHAR(30) not null , 

    location_id VARCHAR(30)  not null,
    constraint fk_car01 foreign key(class_name)REFERENCES car_class (class_name),
	constraint fk_car02 foreign key(location_id)REFERENCES location (location_id) ,
	constraint pk_car primary key(plate),
 ); 

 

CREATE TABLE promotion ( 

    promotion_id VARCHAR(20), 

    discount int not null, 

    class_name VARCHAR(30) not null,
    starting_date date not null,
    ending_date  date,
	constraint pk_promtion primary key(promotion_id),
	constraint fk_promotion01  foreign key (class_name) references car_class(class_name)
	
); 

 

CREATE TABLE customer ( 

    driving_license_no VARCHAR(20), 

    f_name VARCHAR(30), 

    l_name VARCHAR(30), 

    street VARCHAR(30), 

    street_no int, 

    apt int, 

    city VARCHAR(30) , 

    province VARCHAR(30), 

    postal_code VARCHAR(30), 

    country VARCHAR (30),
constraint  pk_driving_license_no primary key( driving_license_no)

); 



CREATE TABLE customer_ph ( 

    area_code int, 
    county_code  int,
    local_code int,
    driving_license_no VARCHAR (20) ,
constraint  pk_customer_ph primary key(driving_license_no,area_code, county_code,local_code),
constraint fk_customer_ph foreign key(driving_license_no) references customer(driving_license_no)

); 

 

CREATE TABLE customer_email ( 

    email VARCHAR(30) not null, 

    driving_licence_no VARCHAR(20) not null,
constraint pk_customer_email primary key(email,driving_licence_no),
constraint fk_customer_email foreign key(driving_licence_no) references customer(driving_license_no)

); 

 

CREATE TABLE rent( 

    rent_id VARCHAR(20) PRIMARY KEY, 

    st_date DATE  not null, 

    end_date DATE, 

    gas_tank DECIMAL not null, 

    int_odo DECIMAL not null, 

    final_odo DECIMAL not null, 
    requested_car_class VARCHAR(30),
    rented_car_class VARCHAR(30),
 plate char(9) ,
    driving_license_no VARCHAR(20),
constraint fk_rent02 foreign key(driving_license_no)   REFERENCES customer (driving_license_no) ,
constraint fk_rent01 foreign key( plate) REFERENCES car (plate),
constraint fk_rent03 foreign key(requested_car_class) references car_class(class_name),
constraint fk_rent04 foreign key(rented_car_class) references car_class(class_name),

); 

 

CREATE TABLE location_rent( 

    location_start DATE not null , 

    location_final DATE not null, 

    rent_id VARCHAR (20),

constraint pk_

); 

 

CREATE TABLE reservation( 

    res_id VARCHAR(20), 
    total_days int,  
    price MONEY ,
    rent_id VARCHAR(20), 
    promotion_id VARCHAR(20)  ,
constraint pk_reservation primary key(res_id),
CONSTRAINT FK_reservation01 FOREIGN KEY (rent_id) REFERENCES rent (rent_id),
CONSTRAINT FK_reservation02 FOREIGN KEY ( promotion_id) REFERENCES promotion  ( promotion_id)

); 


